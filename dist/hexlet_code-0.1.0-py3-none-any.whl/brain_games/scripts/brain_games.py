import sys
sys.path.insert(1, '/home/sat/python-project-lvl1/brain_games')

import cli

def main():
    print("Welcome to the Brain Games!")
    cli.welcome_user()



if __name__ == '__main__':
    main()
    



